package pe.edu.upc.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import pe.edu.upc.entity.Categoria;
import pe.edu.upc.entity.Persona;
import pe.edu.upc.service.ICategoriaService;
import pe.edu.upc.service.IPersonaService;

@Controller
@RequestMapping("/persona")
public class PersonaController {

	@Autowired
	private IPersonaService pService;

	@Autowired
	private ICategoriaService cService;

	@RequestMapping("/")
	public String irPersona(Map<String, Object> model) {
		model.put("listapersonas", pService.listar());
		return "listPersona";
	}

	@RequestMapping("/irRegistrar")
	public String irRegistrar(Model model) {
		model.addAttribute("persona", new Persona());
		model.addAttribute("listaCATEGORIAS", cService.listar());

		return "persona";
	}

	@RequestMapping("/registrar")
	public String registrar(Model model, @ModelAttribute @Valid Persona persona, BindingResult binRes)
			throws ParseException {
		if (binRes.hasErrors()) {
			return "persona";
		} else {

			if (persona.getIdPersona() > 0) {
				pService.modificar(persona);
			} else {
				pService.insertar(persona);
			}
			model.addAttribute("listaCATEGORIAS", cService.listar());
			return "redirect:/persona/listar";

		}
	}

	@RequestMapping("/modificar")
	public String modificar(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		Persona per = pService.listarId(id);
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		per.setFechaString(sdf.format(per.getBirthDatePersona()));
		model.put("listaCATEGORIAS", cService.listar());
		model.put("persona", per);

		return "persona";
	}

	@RequestMapping("/eliminar")
	public String eliminar(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if (id != null && id > 0) {
				pService.eliminar(id);
				model.put("listaPersonas", pService.listar());
			}
			
		} catch (Exception e) {
		System.out.println(e.getMessage());
		}
		return "listPersona";
	}

	@RequestMapping("/listar")
	public String listar(Map<String, Object> model) {

		model.put("listaPersonas", pService.listar());
		return "listPersona";
	}

	@RequestMapping("/listarId")
	public String listarId(Map<String, Object> model, @ModelAttribute Persona persona) {
		pService.listarId(persona.getIdPersona());
		return "listPersona";
	}

	@RequestMapping("/buscar")
	public String buscar(Map<String, Object> model, @ModelAttribute Persona persona) throws ParseException {
		List<Persona> listaPersonas;
		if (StringUtils.isNumeric(persona.getDniPersona())) {

			listaPersonas = pService.findByDniPersona(persona.getDniPersona());

		} else {
			persona.setNamePersona(persona.getDniPersona());
			listaPersonas = pService.buscarNombre(persona.getNamePersona());

			if (listaPersonas.isEmpty()) {
				persona.setEmailPersona(persona.getDniPersona());
				listaPersonas = pService.buscarEmail(persona.getEmailPersona());
			}
			
			if (listaPersonas.isEmpty()) {
				
				listaPersonas = pService.findBynameCategoria(persona.getDniPersona());
			}
			if (listaPersonas.isEmpty()) {
				try {
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
					persona.setBirthDatePersona(sdf.parse(persona.getDniPersona()));
					listaPersonas = pService.findByBirthDatePersona(persona.getBirthDatePersona());
				} catch (Exception e) {
					model.put("mensaje", "Formato incorrecto!!");

				}
			}

		}

		if (listaPersonas.isEmpty()) {

			model.put("mensaje", "No se encontró");
		}
		model.put("listaPersonas", listaPersonas);
		return "buscarPersona";
	}

	@RequestMapping("/irBuscar")
	public String irBuscar(Model model) {
		model.addAttribute("persona", new Persona());
		return "buscarPersona";
	}

}
