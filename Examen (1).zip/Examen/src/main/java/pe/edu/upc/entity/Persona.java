package pe.edu.upc.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "persona")
public class Persona implements Serializable{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idPersona;
	
	@NotEmpty(message="No puede estar vacío")
	@NotBlank(message="No puede estar en blanco")
	@Column(name = "namePersona", length = 60, nullable = false)
	private String namePersona;
	
	@Size(min=8,max=8,message="Debe tener 8 cifras")
	@Range(min=0,max=99999999,message="Debe ser numero")
	@Column(name = "dniPersona", length = 8, nullable = false)
	private String dniPersona;
	
	
	@NotNull 
	@Past(message="La fecha debe estar en el pasado")
	@Temporal(TemporalType.DATE)
	@Column(name = "birthDatePersona")
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date birthDatePersona;
	
	@NotEmpty(message="No puede estar vacío")
	@NotBlank(message="No puede estar en blanco")
	@Email
	@Column(name = "emailPersona", length = 60, nullable = false)
	private String emailPersona;
	
	@ManyToOne
	@JoinColumn(name="idCategoria",nullable=false)
	private Categoria categoria;
	
	private String fechaString;

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public Persona() {
		super();
	}


	public Persona(int idPersona, String namePersona, String dniPersona, Date birthDatePersona, String emailPersona,
			Categoria categoria, String fechaString) {
		super();
		this.idPersona = idPersona;
		this.namePersona = namePersona;
		this.dniPersona = dniPersona;
		this.birthDatePersona = birthDatePersona;
		this.emailPersona = emailPersona;
		this.categoria = categoria;
		this.fechaString = fechaString;
	}

	public int getIdPersona() {
		return idPersona;
	}

	public void setIdPersona(int idPersona) {
		this.idPersona = idPersona;
	}

	public String getNamePersona() {
		return namePersona;
	}

	public void setNamePersona(String namePersona) {
		this.namePersona = namePersona;
	}

	public String getDniPersona() {
		return dniPersona;
	}

	public void setDniPersona(String dniPersona) {
		this.dniPersona = dniPersona;
	}

	public Date getBirthDatePersona() {
		return birthDatePersona;
	}

	public void setBirthDatePersona(Date birthDatePersona) {
		this.birthDatePersona = birthDatePersona;
	}

	public String getEmailPersona() {
		return emailPersona;
	}

	public void setEmailPersona(String emailPersona) {
		this.emailPersona = emailPersona;
	}

	public String getFechaString() {
		return fechaString;
	}

	public void setFechaString(String fechaString) {
		this.fechaString = fechaString;
	}
	
	
}
