package pe.edu.upc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.dao.ICategoriaDAO;
import pe.edu.upc.entity.Categoria;

@Service
public class CategoriaService implements ICategoriaService {

	@Autowired
	private ICategoriaDAO dCategoria;

	@Override
	public void insertar(Categoria categoria) {
		dCategoria.save(categoria);
	}

	@Override
	public void modificar(Categoria categoria) {
		dCategoria.save(categoria);
	}

	@Override
	public void eliminar(int idCategoria) {
		dCategoria.delete(idCategoria);

	}

	@Override
	public Categoria listarId(int idCategoria) {
		return dCategoria.findOne(idCategoria);
	}

	@Override
	public List<Categoria> listar() {
		return dCategoria.findAll();
	}

	@Override
	public List<Categoria> findBynameCategoria(String nameCategoria) {
		return dCategoria.findBynameCategoria(nameCategoria);
	}

}
