package pe.edu.upc.service;

import java.util.Date;
import java.util.List;

import pe.edu.upc.entity.Persona;

public interface IPersonaService {

	void insertar(Persona persona);

	void modificar(Persona persona);

	void eliminar(int idPersona);

	Persona listarId(int idPersona);

	List<Persona> listar();

	List<Persona> findByDniPersona(String dni);

	List<Persona> buscarNombre(String name);

	List<Persona> buscarEmail(String email);

	List<Persona> findByBirthDatePersona(Date birthDate);

	List<Persona> findBynameCategoria(String nameCategoria);

}
