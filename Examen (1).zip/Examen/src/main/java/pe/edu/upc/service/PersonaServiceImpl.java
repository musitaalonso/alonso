package pe.edu.upc.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.edu.upc.dao.IPersonaDAO;
import pe.edu.upc.entity.Persona;
import pe.edu.upc.service.IPersonaService;

@Service
public class PersonaServiceImpl implements IPersonaService{
	
	@Autowired
	private IPersonaDAO dPersona;

	@Override
	public void insertar(Persona persona) {
		dPersona.save(persona);
		
	}

	@Override
	public void modificar(Persona persona) {
		dPersona.save(persona);
		
	}

	@Override
	public void eliminar(int idPersona) {
		dPersona.delete(idPersona);
		
	}

	@Override
	public Persona listarId(int idPersona) {
		return dPersona.findOne(idPersona);
	}

	@Override
	public List<Persona> listar() {
		return dPersona.findAll();
	}

	@Override
	public List<Persona> findByDniPersona(String dni) {
		return dPersona.findByDniPersona(dni);
	}

	@Override
	public List<Persona> buscarNombre(String name) {
		return dPersona.buscarNombre(name);
	}

	@Override
	public List<Persona> buscarEmail(String email) {
		return dPersona.buscarEmail(email);
	}

	@Override
	public List<Persona> findByBirthDatePersona(Date birthDate) {
		return dPersona.findByBirthDatePersona(birthDate);
	}

	@Override
	public List<Persona> findBynameCategoria(String nameCategoria) {
		return dPersona.findBynameCategoria(nameCategoria);
	}
	
	
	
}
